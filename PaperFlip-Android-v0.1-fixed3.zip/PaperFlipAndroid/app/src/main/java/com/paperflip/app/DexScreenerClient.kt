package com.paperflip.app

import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.Executors

/** Public DexScreener read-only market-data client. It never connects to a wallet. */
class DexScreenerClient {
    private val executor = Executors.newFixedThreadPool(3)

    fun fetchSolanaToken(address: String, preferredPairAddress: String? = null, callback: (Result<TokenMarket>) -> Unit) {
        executor.execute {
            try {
                val endpoint = "https://api.dexscreener.com/token-pairs/v1/solana/$address"
                val connection = (URL(endpoint).openConnection() as HttpURLConnection).apply {
                    requestMethod = "GET"
                    connectTimeout = 8_000
                    readTimeout = 10_000
                    setRequestProperty("Accept", "application/json")
                    setRequestProperty("User-Agent", "PaperFlip-Android/0.1")
                }

                val status = connection.responseCode
                val stream = if (status in 200..299) connection.inputStream else connection.errorStream
                val body = stream?.bufferedReader()?.use { it.readText() }.orEmpty()
                connection.disconnect()

                if (status !in 200..299) {
                    val message = when (status) {
                        429 -> "DexScreener rate limit reached. Wait a moment and retry."
                        404 -> "No Solana pools were found for this contract address."
                        else -> "DexScreener returned HTTP $status."
                    }
                    throw IllegalStateException(message)
                }

                val pairs = JSONArray(body)
                if (pairs.length() == 0) {
                    throw IllegalStateException("No trading pairs found for this Solana contract address.")
                }

                val candidates = mutableListOf<Pair<JSONObject, Double>>()
                for (index in 0 until pairs.length()) {
                    val pair = pairs.optJSONObject(index) ?: continue
                    if (!pair.optString("chainId").equals("solana", ignoreCase = true)) continue
                    val base = pair.optJSONObject("baseToken") ?: continue
                    if (!base.optString("address").equals(address, ignoreCase = true)) continue
                    val liquidity = pair.optJSONObject("liquidity")?.optDouble("usd", 0.0) ?: 0.0
                    candidates += pair to liquidity
                }

                if (candidates.isEmpty()) {
                    throw IllegalStateException(
                        "Pools were returned, but none has the token as its base asset. " +
                            "PaperFlip v0.1 needs a standard token/quote pool to calculate SOL fills safely."
                    )
                }

                val preferred = candidates.firstOrNull { it.first.optString("pairAddress").equals(preferredPairAddress, true) }
                val pair = preferred?.first ?: candidates.maxByOrNull { it.second }!!.first
                val base = pair.optJSONObject("baseToken") ?: JSONObject()
                val quote = pair.optJSONObject("quoteToken") ?: JSONObject()
                val info = pair.optJSONObject("info") ?: JSONObject()
                val priceSol = pair.optString("priceNative").toDoubleOrNull() ?: 0.0
                val priceUsd = pair.optString("priceUsd").toDoubleOrNull() ?: 0.0
                if (priceSol <= 0.0 || !priceSol.isFinite()) {
                    throw IllegalStateException("DexScreener did not return a usable native-token price for this pool.")
                }

                val marketCapRaw = pair.optDouble("marketCap", 0.0)
                val fdvRaw = pair.optDouble("fdv", 0.0)
                val useFdv = marketCapRaw <= 0.0 && fdvRaw > 0.0
                val marketCap = if (marketCapRaw > 0.0) marketCapRaw else if (useFdv) fdvRaw else 0.0
                val liquidityUsd = pair.optJSONObject("liquidity")?.optDouble("usd", 0.0) ?: 0.0
                val volume24h = pair.optJSONObject("volume")?.optDouble("h24", 0.0) ?: 0.0
                val imageUrl = info.optString("imageUrl").ifBlank { info.optString("header") }

                callback(
                    Result.success(
                        TokenMarket(
                            chainId = "solana",
                            address = base.optString("address", address),
                            name = base.optString("name", "Unknown token").ifBlank { "Unknown token" },
                            symbol = base.optString("symbol", "???").ifBlank { "???" },
                            imageUrl = imageUrl,
                            pairAddress = pair.optString("pairAddress"),
                            pairUrl = pair.optString("url"),
                            quoteSymbol = quote.optString("symbol", "SOL"),
                            priceSol = priceSol,
                            priceUsd = priceUsd,
                            marketCap = marketCap,
                            marketCapIsFdv = useFdv,
                            liquidityUsd = liquidityUsd,
                            volume24hUsd = volume24h,
                            updatedAt = System.currentTimeMillis()
                        )
                    )
                )
            } catch (error: Exception) {
                callback(Result.failure(error))
            }
        }
    }
}
