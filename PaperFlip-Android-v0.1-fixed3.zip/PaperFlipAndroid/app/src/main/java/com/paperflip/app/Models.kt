package com.paperflip.app

data class TokenMarket(
    val chainId: String,
    val address: String,
    val name: String,
    val symbol: String,
    val imageUrl: String,
    val pairAddress: String,
    val pairUrl: String,
    val quoteSymbol: String,
    val priceSol: Double,
    val priceUsd: Double,
    val marketCap: Double,
    val marketCapIsFdv: Boolean,
    val liquidityUsd: Double,
    val volume24hUsd: Double,
    val updatedAt: Long
)

data class TradePosition(
    val id: Long,
    val chainId: String,
    val tokenAddress: String,
    val tokenName: String,
    val tokenSymbol: String,
    val imageUrl: String,
    val pairAddress: String,
    val pairUrl: String,
    val entryPriceSol: Double,
    val entryMarketCap: Double,
    val latestPriceSol: Double,
    val latestMarketCap: Double,
    val peakMarketCap: Double,
    val boughtTokenQty: Double,
    val remainingTokenQty: Double,
    val remainingCostSol: Double,
    val investedSol: Double,
    val realizedPnlSol: Double,
    val totalFeesSol: Double,
    val openedAt: Long,
    val closedAt: Long?,
    val status: String
) {
    val isOpen: Boolean get() = status == "OPEN"
    val currentValueSol: Double get() = remainingTokenQty * latestPriceSol
    val openPnlSol: Double get() = currentValueSol - remainingCostSol
    val totalPnlSol: Double get() = realizedPnlSol + openPnlSol
    val returnMultiple: Double
        get() = if (investedSol > 0.0) (investedSol + totalPnlSol) / investedSol else 0.0
    val currentCoinMultiple: Double
        get() = if (entryMarketCap > 0.0 && latestMarketCap > 0.0) latestMarketCap / entryMarketCap
        else if (entryPriceSol > 0.0) latestPriceSol / entryPriceSol else 0.0
    val peakCoinMultiple: Double
        get() = if (entryMarketCap > 0.0 && peakMarketCap > 0.0) peakMarketCap / entryMarketCap else 0.0
    val currentMarketCap: Double get() = latestMarketCap
}

data class TradeFill(
    val id: Long,
    val tradeId: Long,
    val side: String,
    val tokenQty: Double,
    val priceSol: Double,
    val marketCap: Double,
    val notionalSol: Double,
    val feeSol: Double,
    val realizedPnlSol: Double,
    val timestamp: Long
)

data class SellResult(
    val tokenQtySold: Double,
    val grossSol: Double,
    val feeSol: Double,
    val netSol: Double,
    val realizedPnlSol: Double,
    val remainingTokenQty: Double,
    val isClosed: Boolean
)
