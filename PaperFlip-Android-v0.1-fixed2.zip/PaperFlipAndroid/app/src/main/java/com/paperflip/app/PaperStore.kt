package com.paperflip.app

import android.content.ContentValues
import android.content.Context
import android.database.Cursor
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

/** Local-only paper portfolio and execution history. */
class PaperStore(context: Context) : SQLiteOpenHelper(context, "paperflip_local.db", null, 1) {
    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL(
            """CREATE TABLE positions (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                chainId TEXT NOT NULL,
                tokenAddress TEXT NOT NULL,
                tokenName TEXT NOT NULL,
                tokenSymbol TEXT NOT NULL,
                imageUrl TEXT NOT NULL,
                pairAddress TEXT NOT NULL,
                pairUrl TEXT NOT NULL,
                entryPriceSol REAL NOT NULL,
                entryMarketCap REAL NOT NULL,
                latestPriceSol REAL NOT NULL,
                latestMarketCap REAL NOT NULL,
                peakMarketCap REAL NOT NULL,
                boughtTokenQty REAL NOT NULL,
                remainingTokenQty REAL NOT NULL,
                remainingCostSol REAL NOT NULL,
                investedSol REAL NOT NULL,
                realizedPnlSol REAL NOT NULL,
                totalFeesSol REAL NOT NULL,
                openedAt INTEGER NOT NULL,
                closedAt INTEGER,
                status TEXT NOT NULL
            )""".trimIndent()
        )
        db.execSQL("CREATE INDEX idx_positions_status ON positions(status)")
        db.execSQL("CREATE INDEX idx_positions_token ON positions(tokenAddress)")
        db.execSQL(
            """CREATE TABLE fills (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                tradeId INTEGER NOT NULL,
                side TEXT NOT NULL,
                tokenQty REAL NOT NULL,
                priceSol REAL NOT NULL,
                marketCap REAL NOT NULL,
                notionalSol REAL NOT NULL,
                feeSol REAL NOT NULL,
                realizedPnlSol REAL NOT NULL,
                timestamp INTEGER NOT NULL,
                FOREIGN KEY(tradeId) REFERENCES positions(id)
            )""".trimIndent()
        )
        db.execSQL("CREATE INDEX idx_fills_trade ON fills(tradeId, timestamp)")
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        // v0.1 has no released upgrade path yet. Future migrations will be explicit here.
    }

    fun recordBuy(
        coin: TokenMarket,
        notionalSol: Double,
        feeSol: Double,
        executedPriceSol: Double,
        tokenQty: Double
    ): Long {
        val db = writableDatabase
        db.beginTransaction()
        try {
            val now = System.currentTimeMillis()
            val existing = db.rawQuery(
                "SELECT * FROM positions WHERE tokenAddress=? AND pairAddress=? AND status='OPEN' LIMIT 1",
                arrayOf(coin.address, coin.pairAddress)
            ).use { cursor -> if (cursor.moveToFirst()) readPosition(cursor) else null }

            val tradeId: Long
            if (existing == null) {
                val values = ContentValues().apply {
                    put("chainId", coin.chainId)
                    put("tokenAddress", coin.address)
                    put("tokenName", coin.name)
                    put("tokenSymbol", coin.symbol)
                    put("imageUrl", coin.imageUrl)
                    put("pairAddress", coin.pairAddress)
                    put("pairUrl", coin.pairUrl)
                    put("entryPriceSol", executedPriceSol)
                    put("entryMarketCap", coin.marketCap)
                    put("latestPriceSol", coin.priceSol)
                    put("latestMarketCap", coin.marketCap)
                    put("peakMarketCap", coin.marketCap)
                    put("boughtTokenQty", tokenQty)
                    put("remainingTokenQty", tokenQty)
                    put("remainingCostSol", notionalSol + feeSol)
                    put("investedSol", notionalSol + feeSol)
                    put("realizedPnlSol", 0.0)
                    put("totalFeesSol", feeSol)
                    put("openedAt", now)
                    putNull("closedAt")
                    put("status", "OPEN")
                }
                tradeId = db.insertOrThrow("positions", null, values)
            } else {
                val oldQty = existing.boughtTokenQty
                val newQty = oldQty + tokenQty
                val weightedEntry = if (newQty > 0.0) {
                    ((existing.entryPriceSol * oldQty) + (executedPriceSol * tokenQty)) / newQty
                } else executedPriceSol
                val values = ContentValues().apply {
                    put("tokenName", coin.name)
                    put("tokenSymbol", coin.symbol)
                    put("imageUrl", coin.imageUrl)
                    put("pairUrl", coin.pairUrl)
                    put("entryPriceSol", weightedEntry)
                    put("boughtTokenQty", newQty)
                    put("remainingTokenQty", existing.remainingTokenQty + tokenQty)
                    put("remainingCostSol", existing.remainingCostSol + notionalSol + feeSol)
                    put("investedSol", existing.investedSol + notionalSol + feeSol)
                    put("totalFeesSol", existing.totalFeesSol + feeSol)
                    put("latestPriceSol", coin.priceSol)
                    put("latestMarketCap", coin.marketCap)
                    put("peakMarketCap", maxOf(existing.peakMarketCap, coin.marketCap))
                }
                db.update("positions", values, "id=?", arrayOf(existing.id.toString()))
                tradeId = existing.id
            }

            insertFill(
                db = db,
                tradeId = tradeId,
                side = "BUY",
                tokenQty = tokenQty,
                priceSol = executedPriceSol,
                marketCap = coin.marketCap,
                notionalSol = notionalSol,
                feeSol = feeSol,
                realizedPnlSol = 0.0,
                timestamp = now
            )
            db.setTransactionSuccessful()
            return tradeId
        } finally {
            db.endTransaction()
        }
    }

    @Throws(IllegalStateException::class)
    fun recordSell(
        tradeId: Long,
        percentOfRemaining: Double,
        executedPriceSol: Double,
        marketCap: Double,
        feePercent: Double,
        fixedFeeSol: Double
    ): SellResult {
        val db = writableDatabase
        db.beginTransaction()
        try {
            val position = queryPosition(db, tradeId)
                ?: throw IllegalStateException("This paper position no longer exists.")
            if (!position.isOpen || position.remainingTokenQty <= 0.0) {
                throw IllegalStateException("There is no remaining position to sell.")
            }

            val fraction = percentOfRemaining.coerceIn(0.0, 1.0)
            val qtyToSell = if (fraction >= 0.999999) position.remainingTokenQty
            else position.remainingTokenQty * fraction
            if (qtyToSell <= 0.0) throw IllegalStateException("Sell quantity is too small.")

            val grossSol = qtyToSell * executedPriceSol
            val feeSol = grossSol * (feePercent / 100.0) + fixedFeeSol
            if (feeSol >= grossSol) {
                throw IllegalStateException("Configured fees are greater than this simulated sale. Reduce the fixed fee or sell a larger amount.")
            }
            val netSol = grossSol - feeSol
            val allocatedCost = position.remainingCostSol * (qtyToSell / position.remainingTokenQty)
            val realizedPnl = netSol - allocatedCost
            val remainingQty = (position.remainingTokenQty - qtyToSell).coerceAtLeast(0.0)
            val remainingCost = (position.remainingCostSol - allocatedCost).coerceAtLeast(0.0)
            val closed = remainingQty <= position.boughtTokenQty * 1e-10
            val now = System.currentTimeMillis()

            val values = ContentValues().apply {
                put("remainingTokenQty", if (closed) 0.0 else remainingQty)
                put("remainingCostSol", if (closed) 0.0 else remainingCost)
                put("realizedPnlSol", position.realizedPnlSol + realizedPnl)
                put("totalFeesSol", position.totalFeesSol + feeSol)
                put("latestPriceSol", executedPriceSol)
                put("latestMarketCap", marketCap)
                put("peakMarketCap", maxOf(position.peakMarketCap, marketCap))
                put("status", if (closed) "CLOSED" else "OPEN")
                if (closed) put("closedAt", now)
            }
            db.update("positions", values, "id=?", arrayOf(tradeId.toString()))
            insertFill(
                db = db,
                tradeId = tradeId,
                side = "SELL",
                tokenQty = qtyToSell,
                priceSol = executedPriceSol,
                marketCap = marketCap,
                notionalSol = grossSol,
                feeSol = feeSol,
                realizedPnlSol = realizedPnl,
                timestamp = now
            )
            db.setTransactionSuccessful()
            return SellResult(qtyToSell, grossSol, feeSol, netSol, realizedPnl, if (closed) 0.0 else remainingQty, closed)
        } finally {
            db.endTransaction()
        }
    }

    fun updateMarket(coin: TokenMarket) {
        val db = writableDatabase
        val liveValues = ContentValues().apply {
            put("latestPriceSol", coin.priceSol)
            put("latestMarketCap", coin.marketCap)
        }
        db.update(
            "positions",
            liveValues,
            "tokenAddress=? AND pairAddress=? AND status='OPEN'",
            arrayOf(coin.address, coin.pairAddress)
        )
        // Keep recording the highest observed market cap for up to 24h after exit,
        // without overwriting the actual exit price/market cap stored on the trade.
        val postExitCutoff = System.currentTimeMillis() - 24L * 60L * 60L * 1000L
        db.execSQL(
            """UPDATE positions
               SET peakMarketCap = CASE WHEN ? > peakMarketCap THEN ? ELSE peakMarketCap END
               WHERE tokenAddress=? AND pairAddress=?
                 AND (status='OPEN' OR (closedAt IS NOT NULL AND closedAt >= ?))""".trimIndent(),
            arrayOf(coin.marketCap, coin.marketCap, coin.address, coin.pairAddress, postExitCutoff)
        )
    }

    fun getOpenPositions(): List<TradePosition> = queryPositions("status='OPEN'", null)
    fun getAllPositions(): List<TradePosition> = queryPositions(null, null)

    fun getPositionForToken(address: String): TradePosition? {
        return readableDatabase.rawQuery(
            "SELECT * FROM positions WHERE tokenAddress=? AND status='OPEN' ORDER BY openedAt DESC LIMIT 1",
            arrayOf(address)
        ).use { cursor -> if (cursor.moveToFirst()) readPosition(cursor) else null }
    }

    fun getPositionById(id: Long): TradePosition? = queryPosition(readableDatabase, id)

    fun getFills(tradeId: Long): List<TradeFill> {
        val result = mutableListOf<TradeFill>()
        readableDatabase.rawQuery(
            "SELECT * FROM fills WHERE tradeId=? ORDER BY timestamp ASC, id ASC",
            arrayOf(tradeId.toString())
        ).use { cursor ->
            while (cursor.moveToNext()) result += readFill(cursor)
        }
        return result
    }

    fun deleteAllPaperData() {
        writableDatabase.beginTransaction()
        try {
            writableDatabase.delete("fills", null, null)
            writableDatabase.delete("positions", null, null)
            writableDatabase.setTransactionSuccessful()
        } finally {
            writableDatabase.endTransaction()
        }
    }

    private fun queryPositions(selection: String?, args: Array<String>?): List<TradePosition> {
        val result = mutableListOf<TradePosition>()
        readableDatabase.query(
            "positions", null, selection, args, null, null, "openedAt DESC"
        ).use { cursor ->
            while (cursor.moveToNext()) result += readPosition(cursor)
        }
        return result
    }

    private fun queryPosition(db: SQLiteDatabase, id: Long): TradePosition? {
        return db.rawQuery("SELECT * FROM positions WHERE id=? LIMIT 1", arrayOf(id.toString()))
            .use { cursor -> if (cursor.moveToFirst()) readPosition(cursor) else null }
    }

    private fun readPosition(c: Cursor): TradePosition = TradePosition(
        id = c.getLong(c.getColumnIndexOrThrow("id")),
        chainId = c.getString(c.getColumnIndexOrThrow("chainId")),
        tokenAddress = c.getString(c.getColumnIndexOrThrow("tokenAddress")),
        tokenName = c.getString(c.getColumnIndexOrThrow("tokenName")),
        tokenSymbol = c.getString(c.getColumnIndexOrThrow("tokenSymbol")),
        imageUrl = c.getString(c.getColumnIndexOrThrow("imageUrl")),
        pairAddress = c.getString(c.getColumnIndexOrThrow("pairAddress")),
        pairUrl = c.getString(c.getColumnIndexOrThrow("pairUrl")),
        entryPriceSol = c.getDouble(c.getColumnIndexOrThrow("entryPriceSol")),
        entryMarketCap = c.getDouble(c.getColumnIndexOrThrow("entryMarketCap")),
        latestPriceSol = c.getDouble(c.getColumnIndexOrThrow("latestPriceSol")),
        latestMarketCap = c.getDouble(c.getColumnIndexOrThrow("latestMarketCap")),
        peakMarketCap = c.getDouble(c.getColumnIndexOrThrow("peakMarketCap")),
        boughtTokenQty = c.getDouble(c.getColumnIndexOrThrow("boughtTokenQty")),
        remainingTokenQty = c.getDouble(c.getColumnIndexOrThrow("remainingTokenQty")),
        remainingCostSol = c.getDouble(c.getColumnIndexOrThrow("remainingCostSol")),
        investedSol = c.getDouble(c.getColumnIndexOrThrow("investedSol")),
        realizedPnlSol = c.getDouble(c.getColumnIndexOrThrow("realizedPnlSol")),
        totalFeesSol = c.getDouble(c.getColumnIndexOrThrow("totalFeesSol")),
        openedAt = c.getLong(c.getColumnIndexOrThrow("openedAt")),
        closedAt = if (c.isNull(c.getColumnIndexOrThrow("closedAt"))) null else c.getLong(c.getColumnIndexOrThrow("closedAt")),
        status = c.getString(c.getColumnIndexOrThrow("status"))
    )

    private fun readFill(c: Cursor): TradeFill = TradeFill(
        id = c.getLong(c.getColumnIndexOrThrow("id")),
        tradeId = c.getLong(c.getColumnIndexOrThrow("tradeId")),
        side = c.getString(c.getColumnIndexOrThrow("side")),
        tokenQty = c.getDouble(c.getColumnIndexOrThrow("tokenQty")),
        priceSol = c.getDouble(c.getColumnIndexOrThrow("priceSol")),
        marketCap = c.getDouble(c.getColumnIndexOrThrow("marketCap")),
        notionalSol = c.getDouble(c.getColumnIndexOrThrow("notionalSol")),
        feeSol = c.getDouble(c.getColumnIndexOrThrow("feeSol")),
        realizedPnlSol = c.getDouble(c.getColumnIndexOrThrow("realizedPnlSol")),
        timestamp = c.getLong(c.getColumnIndexOrThrow("timestamp"))
    )

    private fun insertFill(
        db: SQLiteDatabase,
        tradeId: Long,
        side: String,
        tokenQty: Double,
        priceSol: Double,
        marketCap: Double,
        notionalSol: Double,
        feeSol: Double,
        realizedPnlSol: Double,
        timestamp: Long
    ) {
        val values = ContentValues().apply {
            put("tradeId", tradeId)
            put("side", side)
            put("tokenQty", tokenQty)
            put("priceSol", priceSol)
            put("marketCap", marketCap)
            put("notionalSol", notionalSol)
            put("feeSol", feeSol)
            put("realizedPnlSol", realizedPnlSol)
            put("timestamp", timestamp)
        }
        db.insertOrThrow("fills", null, values)
    }
}
