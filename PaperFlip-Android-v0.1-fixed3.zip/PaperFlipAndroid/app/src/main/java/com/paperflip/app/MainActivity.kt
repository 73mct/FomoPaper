package com.paperflip.app

import android.app.Activity
import android.app.AlertDialog
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.WindowInsets
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import java.net.URL
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.Executors
import kotlin.math.abs

class MainActivity : Activity() {
    private lateinit var store: PaperStore
    private lateinit var prefs: android.content.SharedPreferences
    private val api = DexScreenerClient()
    private val imageExecutor = Executors.newFixedThreadPool(2)
    private val handler = Handler(Looper.getMainLooper())

    private lateinit var root: LinearLayout
    private lateinit var body: LinearLayout
    private lateinit var tabsContainer: LinearLayout
    private var currentPage = Page.TRADE
    private var loadedCoin: TokenMarket? = null
    private var caDraft = ""
    private var loadingCoin = false
    private var statusMessage = "Paste a Solana token CA to begin."
    private var journalFilter = JournalFilter.ALL
    private val expandedTrades = mutableSetOf<Long>()
    private var customBuyField: EditText? = null
    private var settingsFields = mutableMapOf<String, EditText>()

    private enum class Page { TRADE, JOURNAL, SETTINGS }
    private enum class JournalFilter { ALL, OPEN, CLOSED }

    private val refreshTask = object : Runnable {
        override fun run() {
            refreshTrackedMarkets(showToast = false)
            handler.postDelayed(this, 20_000L)
        }
    }

    private val prefsBalanceKey = "paper_balance_sol"
    private val prefsInitialBalanceKey = "initial_balance_sol"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(8, 13, 20)
        window.navigationBarColor = Color.rgb(8, 13, 20)
        if (Build.VERSION.SDK_INT >= 29) {
            window.isNavigationBarContrastEnforced = false
            window.isStatusBarContrastEnforced = false
        }

        store = PaperStore(this)
        prefs = getSharedPreferences("paperflip_preferences", Context.MODE_PRIVATE)
        if (!prefs.contains(prefsBalanceKey)) {
            prefs.edit().putFloat(prefsBalanceKey, 7.44f).putFloat(prefsInitialBalanceKey, 7.44f).apply()
        }
        setContentView(buildBaseLayout())
        renderPage()
    }

    override fun onResume() {
        super.onResume()
        handler.removeCallbacks(refreshTask)
        handler.postDelayed(refreshTask, 4_000L)
    }

    override fun onPause() {
        handler.removeCallbacks(refreshTask)
        super.onPause()
    }

    private fun buildBaseLayout(): View {
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(C_BG)
            setPadding(dp(16), dp(8), dp(16), dp(8))
        }
        if (Build.VERSION.SDK_INT >= 30) {
            root.setOnApplyWindowInsetsListener { view, insets ->
                val bars = insets.getInsets(WindowInsets.Type.systemBars())
                view.setPadding(dp(16), bars.top + dp(8), dp(16), bars.bottom + dp(8))
                insets
            }
        }

        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, dp(5), 0, dp(14))
        }
        val brandColumn = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        brandColumn.addView(text("PaperFlip", 23f, C_TEXT, true))
        brandColumn.addView(text("SOLANA PAPER TRADING TERMINAL", 9f, C_MUTED, true))
        header.addView(brandColumn, LinearLayout.LayoutParams(0, -2, 1f))
        header.addView(pill("PAPER MODE", C_GREEN_DARK, C_GREEN, 10f))
        root.addView(header)

        tabsContainer = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            background = rounded(C_PANEL, dp(13), C_BORDER, dp(1))
            setPadding(dp(4), dp(4), dp(4), dp(4))
        }
        tabsContainer.addView(tabButton("Trade", Page.TRADE), LinearLayout.LayoutParams(0, dp(42), 1f))
        tabsContainer.addView(tabButton("Journal", Page.JOURNAL), LinearLayout.LayoutParams(0, dp(42), 1f))
        tabsContainer.addView(tabButton("Settings", Page.SETTINGS), LinearLayout.LayoutParams(0, dp(42), 1f))
        root.addView(tabsContainer, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(12) })

        val scroll = ScrollView(this).apply {
            isFillViewport = true
            clipToPadding = false
            setVerticalScrollBarEnabled(false)
        }
        body = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(0, 0, 0, dp(24))
        }
        scroll.addView(body, ViewGroup.LayoutParams(-1, -2))
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))

        val footer = TextView(this).apply {
            text = "SIMULATED TRADES ONLY  •  NO WALLET CONNECTION"
            textSize = 9f
            setTextColor(C_MUTED)
            gravity = Gravity.CENTER
            setPadding(0, dp(8), 0, 0)
        }
        root.addView(footer)
        return root
    }

    private fun tabButton(label: String, page: Page): View {
        val active = currentPage == page
        return TextView(this).apply {
            text = label
            gravity = Gravity.CENTER
            textSize = 13f
            typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
            setTextColor(if (active) C_TEXT else C_MUTED)
            background = if (active) rounded(C_ACTIVE_TAB, dp(10)) else rounded(Color.TRANSPARENT, dp(10))
            setOnClickListener {
                currentPage = page
                renderPage()
            }
        }
    }

    private fun renderPage() {
        if (!::body.isInitialized) return
        body.removeAllViews()
        when (currentPage) {
            Page.TRADE -> buildTradePage()
            Page.JOURNAL -> buildJournalPage()
            Page.SETTINGS -> buildSettingsPage()
        }
        if (::tabsContainer.isInitialized) {
            val pages = listOf(Page.TRADE, Page.JOURNAL, Page.SETTINGS)
            for (index in pages.indices) {
                val tab = tabsContainer.getChildAt(index) as? TextView ?: continue
                val active = pages[index] == currentPage
                tab.setTextColor(if (active) C_TEXT else C_MUTED)
                tab.background = if (active) rounded(C_ACTIVE_TAB, dp(10)) else rounded(Color.TRANSPARENT, dp(10))
            }
        }
    }

    private fun buildTradePage() {
        addBalanceCard()
        sectionTitle("IDENTIFY TOKEN", "Paste the Solana mint address from FOMO or Axiom")

        val lookupCard = card()
        lookupCard.addView(label("TOKEN CONTRACT ADDRESS / CA"))
        val inputRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val input = editField("Paste Solana token CA", caDraft)
        input.addTextChangedListener(SimpleTextWatcher { caDraft = it.trim() })
        inputRow.addView(input, LinearLayout.LayoutParams(0, dp(48), 1f))
        inputRow.addView(spacerWidth(8))
        inputRow.addView(actionButton("Paste", C_PANEL_LIGHT, C_TEXT) { pasteAddress(input) }, LinearLayout.LayoutParams(dp(78), dp(48)))
        lookupCard.addView(inputRow)
        lookupCard.addView(spacer(10))
        lookupCard.addView(actionButton(if (loadingCoin) "Loading token…" else "Load coin", C_GREEN_DARK, C_GREEN) {
            caDraft = input.text.toString().trim()
            loadCoin(caDraft)
        }, LinearLayout.LayoutParams(-1, dp(46)))
        lookupCard.addView(spacer(7))
        lookupCard.addView(text(statusMessage, 11f, C_MUTED))
        body.addView(lookupCard)

        val coin = loadedCoin
        if (coin != null) {
            buildCoinCard(coin)
            buildBuyCard(coin)
            val openPosition = store.getOpenPositions().firstOrNull {
                it.tokenAddress.equals(coin.address, true) && it.pairAddress.equals(coin.pairAddress, true)
            }
            if (openPosition != null) buildOpenPositionCard(openPosition, coin)
            else {
                val noPosition = card()
                noPosition.addView(text("No open paper position for this pool yet.", 13f, C_MUTED))
                body.addView(noPosition)
            }
        } else {
            val hint = card()
            hint.addView(text("Your coin will appear here", 15f, C_TEXT, true))
            hint.addView(spacer(4))
            hint.addView(text("After loading a CA, PaperFlip will show the selected pool, live market cap, liquidity and SOL price. You can then simulate buys and sells without connecting a wallet.", 12f, C_MUTED))
            body.addView(hint)
        }
    }

    private fun addBalanceCard() {
        val card = card(C_PANEL)
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val left = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        left.addView(label("PAPER WALLET BALANCE"))
        left.addView(text("${fmtSol(balanceSol())} SOL", 25f, C_TEXT, true))
        left.addView(text("No real funds • local simulation", 10f, C_MUTED))
        row.addView(left, LinearLayout.LayoutParams(0, -2, 1f))
        val openCount = store.getOpenPositions().size
        val right = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.END }
        right.addView(label("OPEN POSITIONS"))
        right.addView(text(openCount.toString(), 24f, C_GREEN, true))
        row.addView(right)
        card.addView(row)
        body.addView(card)
    }

    private fun buildCoinCard(coin: TokenMarket) {
        val card = card()
        val top = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        top.addView(tokenAvatar(coin.symbol, coin.imageUrl, 44), LinearLayout.LayoutParams(dp(44), dp(44)))
        val identity = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(10), 0, 0, 0) }
        identity.addView(text(coin.name, 17f, C_TEXT, true))
        identity.addView(text("${coin.symbol}  •  Solana", 11f, C_MUTED))
        top.addView(identity, LinearLayout.LayoutParams(0, -2, 1f))
        top.addView(actionButton("Open chart", C_PANEL_LIGHT, C_TEXT) {
            if (coin.pairUrl.isNotBlank()) openUrl(coin.pairUrl)
            else toast("No DexScreener chart link was returned.")
        })
        card.addView(top)
        card.addView(spacer(13))
        val values = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        values.addView(metric("MARKET CAP${if (coin.marketCapIsFdv) " / FDV" else ""}", if (coin.marketCap > 0) fmtUsd(coin.marketCap) else "Unavailable", C_TEXT), LinearLayout.LayoutParams(0, -2, 1f))
        values.addView(metric("PRICE (SOL)", fmtPriceSol(coin.priceSol), C_GREEN), LinearLayout.LayoutParams(0, -2, 1f))
        values.addView(metric("LIQUIDITY", fmtUsd(coin.liquidityUsd), C_TEXT), LinearLayout.LayoutParams(0, -2, 1f))
        card.addView(values)
        card.addView(spacer(10))
        val sub = "24h volume ${fmtUsd(coin.volume24hUsd)}  •  Pool ${shortAddress(coin.pairAddress)}"
        card.addView(text(sub, 10f, C_MUTED))
        card.addView(text("Updated ${timeClock(coin.updatedAt)}  •  Highest-liquidity pool selected", 10f, C_MUTED))
        body.addView(card)
    }

    private fun buildBuyCard(coin: TokenMarket) {
        val card = card()
        card.addView(sectionHeader("INSTANT BUY", "SOL"))
        card.addView(text("Choose the simulated amount to spend", 11f, C_MUTED))
        card.addView(spacer(9))
        val firstRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        listOf(0.25, 0.5, 1.0, 2.5).forEachIndexed { index, amount ->
            val button = actionButton("${amount} SOL", C_GREEN_DARK, C_GREEN) { executeBuy(coin, amount) }
            firstRow.addView(button, LinearLayout.LayoutParams(0, dp(44), 1f).apply {
                if (index != 3) rightMargin = dp(6)
            })
        }
        card.addView(firstRow)
        card.addView(spacer(10))
        val customRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val custom = editField("Custom SOL", "")
        custom.inputType = android.text.InputType.TYPE_CLASS_NUMBER or android.text.InputType.TYPE_NUMBER_FLAG_DECIMAL
        customBuyField = custom
        customRow.addView(custom, LinearLayout.LayoutParams(0, dp(44), 1f))
        customRow.addView(spacerWidth(8))
        customRow.addView(actionButton("Buy custom", C_GREEN_DARK, C_GREEN) {
            val amount = custom.text.toString().toDoubleOrNull()
            if (amount == null || amount <= 0.0) toast("Enter a valid SOL amount.")
            else executeBuy(coin, amount)
        }, LinearLayout.LayoutParams(dp(120), dp(44)))
        card.addView(customRow)
        card.addView(spacer(9))
        card.addView(text("Fee ${feePercent()}% + ${fmtSol(fixedFeeSol())} SOL  •  Slippage ${slippagePercent()}%", 10f, C_MUTED))
        body.addView(card)
    }

    private fun buildOpenPositionCard(position: TradePosition, coin: TokenMarket) {
        val card = card()
        card.addView(sectionHeader("OPEN PAPER POSITION", "${position.tokenSymbol}"))
        val pnlColor = if (position.openPnlSol >= 0.0) C_GREEN else C_RED
        val pnlRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val pnlColumn = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        pnlColumn.addView(label("UNREALIZED PNL"))
        pnlColumn.addView(text(signedSol(position.openPnlSol), 22f, pnlColor, true))
        pnlRow.addView(pnlColumn, LinearLayout.LayoutParams(0, -2, 1f))
        pnlRow.addView(metric("COIN MULTIPLE", "${fmtMultiple(position.currentCoinMultiple)}x", pnlColor))
        card.addView(pnlRow)
        card.addView(spacer(10))
        card.addView(text("Remaining ${fmtQty(position.remainingTokenQty)} tokens  •  Value ${fmtSol(position.currentValueSol)} SOL", 11f, C_MUTED))
        card.addView(text("Entry MC ${fmtOptionalMc(position.entryMarketCap)}  →  Now ${fmtOptionalMc(coin.marketCap)}", 11f, C_MUTED))
        card.addView(spacer(12))
        card.addView(label("SELL % OF REMAINING POSITION"))
        card.addView(spacer(7))
        val sellRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        listOf(25, 50, 75, 100).forEachIndexed { index, percent ->
            sellRow.addView(
                actionButton("$percent%", C_RED_DARK, C_RED) { executeSell(position, percent / 100.0, coin) },
                LinearLayout.LayoutParams(0, dp(44), 1f).apply { if (index != 3) rightMargin = dp(6) }
            )
        }
        card.addView(sellRow)
        card.addView(spacer(7))
        card.addView(text("Each sell percentage applies to the position still remaining, not the original buy.", 10f, C_MUTED))
        body.addView(card)
    }

    private fun buildJournalPage() {
        val positions = store.getAllPositions()
        val openPositions = positions.filter { it.isOpen }
        val totalRealized = positions.sumOf { it.realizedPnlSol }
        val totalUnrealized = openPositions.sumOf { it.openPnlSol }
        val totalPnl = totalRealized + totalUnrealized

        val summary = card()
        summary.addView(label("PAPER PERFORMANCE"))
        summary.addView(text(signedSol(totalPnl), 28f, if (totalPnl >= 0) C_GREEN else C_RED, true))
        summary.addView(spacer(8))
        val stats = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        stats.addView(metric("REALIZED", signedSol(totalRealized), if (totalRealized >= 0) C_GREEN else C_RED), LinearLayout.LayoutParams(0, -2, 1f))
        stats.addView(metric("UNREALIZED", signedSol(totalUnrealized), if (totalUnrealized >= 0) C_GREEN else C_RED), LinearLayout.LayoutParams(0, -2, 1f))
        stats.addView(metric("TRADES", positions.size.toString(), C_TEXT), LinearLayout.LayoutParams(0, -2, 1f))
        summary.addView(stats)
        body.addView(summary)

        val controls = card(C_PANEL)
        controls.addView(sectionHeader("TRADE JOURNAL", "${openPositions.size} OPEN"))
        val filters = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        listOf(JournalFilter.ALL to "All", JournalFilter.OPEN to "Open", JournalFilter.CLOSED to "Closed").forEachIndexed { index, pair ->
            filters.addView(
                actionButton(pair.second, if (journalFilter == pair.first) C_ACTIVE_TAB else C_PANEL_LIGHT, if (journalFilter == pair.first) C_TEXT else C_MUTED) {
                    journalFilter = pair.first
                    renderPage()
                },
                LinearLayout.LayoutParams(0, dp(40), 1f).apply { if (index != 2) rightMargin = dp(6) }
            )
        }
        controls.addView(filters)
        controls.addView(spacer(8))
        controls.addView(actionButton("Refresh open market data", C_PANEL_LIGHT, C_TEXT) { refreshTrackedMarkets(showToast = true) })
        body.addView(controls)

        val filtered = when (journalFilter) {
            JournalFilter.ALL -> positions
            JournalFilter.OPEN -> positions.filter { it.isOpen }
            JournalFilter.CLOSED -> positions.filter { !it.isOpen }
        }
        if (filtered.isEmpty()) {
            val empty = card()
            empty.addView(text("Your journal is empty", 16f, C_TEXT, true))
            empty.addView(spacer(5))
            empty.addView(text("Your first paper buy will automatically create a trade record with its CA, pool, entry, fills, fees and holding time.", 12f, C_MUTED))
            body.addView(empty)
        } else {
            filtered.forEach { position -> buildJournalTradeCard(position) }
        }
    }

    private fun buildJournalTradeCard(position: TradePosition) {
        val card = card()
        val header = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        header.addView(tokenAvatar(position.tokenSymbol, position.imageUrl, 38), LinearLayout.LayoutParams(dp(38), dp(38)))
        val identity = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(9), 0, 0, 0) }
        identity.addView(text("${position.tokenName} (${position.tokenSymbol})", 15f, C_TEXT, true))
        identity.addView(text(shortAddress(position.tokenAddress), 10f, C_MUTED))
        header.addView(identity, LinearLayout.LayoutParams(0, -2, 1f))
        header.addView(pill(if (position.isOpen) "OPEN" else "CLOSED", if (position.isOpen) C_GREEN_DARK else C_PANEL_LIGHT, if (position.isOpen) C_GREEN else C_MUTED, 9f))
        card.addView(header)
        card.addView(spacer(11))

        val pnl = position.totalPnlSol
        val metrics = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        metrics.addView(metric("TOTAL PNL", signedSol(pnl), if (pnl >= 0) C_GREEN else C_RED), LinearLayout.LayoutParams(0, -2, 1f))
        metrics.addView(metric("PEAK COIN X", fmtOptionalMultiple(position.peakCoinMultiple), if (position.peakCoinMultiple >= 1.0) C_GREEN else C_RED), LinearLayout.LayoutParams(0, -2, 1f))
        metrics.addView(metric("PEAK MC / FDV", fmtOptionalMc(position.peakMarketCap), C_TEXT), LinearLayout.LayoutParams(0, -2, 1f))
        card.addView(metrics)
        card.addView(spacer(9))
        card.addView(text("Entry MC/FDV ${fmtOptionalMc(position.entryMarketCap)}  •  ${if (position.isOpen) "Current" else "Exit"} MC/FDV ${fmtOptionalMc(position.latestMarketCap)}", 11f, C_MUTED))
        card.addView(text("Peak MC/FDV observed since entry: ${fmtOptionalMc(position.peakMarketCap)} (${fmtOptionalMultiple(position.peakCoinMultiple)})", 11f, C_MUTED))
        card.addView(text("Invested ${fmtSol(position.investedSol)} SOL  •  Fees ${fmtSol(position.totalFeesSol)} SOL", 11f, C_MUTED))
        card.addView(text("Held ${duration(position.openedAt, position.closedAt ?: System.currentTimeMillis())}${if (position.isOpen) " (running)" else ""}", 11f, C_MUTED))
        if (position.isOpen) {
            card.addView(text("Remaining value ${fmtSol(position.currentValueSol)} SOL  •  Unrealized ${signedSol(position.openPnlSol)}", 11f, if (position.openPnlSol >= 0) C_GREEN else C_RED))
        } else {
            card.addView(text("Final exit MC ${fmtOptionalMc(position.latestMarketCap)}  •  Realized ${signedSol(position.realizedPnlSol)}", 11f, if (position.realizedPnlSol >= 0) C_GREEN else C_RED))
        }

        val expanded = expandedTrades.contains(position.id)
        card.addView(spacer(10))
        card.addView(actionButton(if (expanded) "Hide execution history" else "View execution history", C_PANEL_LIGHT, C_TEXT) {
            if (expanded) expandedTrades.remove(position.id) else expandedTrades.add(position.id)
            renderPage()
        })
        if (expanded) {
            card.addView(spacer(8))
            store.getFills(position.id).forEach { fill ->
                val fillColor = if (fill.side == "BUY") C_GREEN else C_RED
                card.addView(text("${fill.side}  •  ${dateTime(fill.timestamp)}", 11f, fillColor, true))
                card.addView(text("${fmtQty(fill.tokenQty)} tokens @ ${fmtPriceSol(fill.priceSol)}  •  ${fmtSol(fill.notionalSol)} SOL notional", 10f, C_MUTED))
                card.addView(text("MC/FDV ${fmtOptionalMc(fill.marketCap)}  •  Fee ${fmtSol(fill.feeSol)} SOL${if (fill.side == "SELL") "  •  Realized ${signedSol(fill.realizedPnlSol)}" else ""}", 10f, C_MUTED))
                card.addView(spacer(7))
            }
            card.addView(actionButton("Copy token CA", C_PANEL_LIGHT, C_TEXT) { copyText(position.tokenAddress, "Token CA copied") })
            if (position.pairUrl.isNotBlank()) {
                card.addView(spacer(6))
                card.addView(actionButton("Open pool chart", C_PANEL_LIGHT, C_TEXT) { openUrl(position.pairUrl) })
            }
        }
        body.addView(card)
    }

    private fun buildSettingsPage() {
        val settings = card()
        settings.addView(text("Simulation settings", 17f, C_TEXT, true))
        settings.addView(text("These values affect simulated balances and fills only. They never affect a wallet or a blockchain transaction.", 11f, C_MUTED))
        settings.addView(spacer(12))

        settingsFields.clear()
        addSettingField(settings, "Initial wallet balance (SOL)", "initial", prefs.getFloat(prefsInitialBalanceKey, 7.44f).toString())
        addSettingField(settings, "Trading fee (%) per fill", "feePct", feePercent().toString())
        addSettingField(settings, "Fixed fee (SOL) per fill", "fixedFee", fixedFeeSol().toString())
        addSettingField(settings, "Slippage (%) per fill", "slippage", slippagePercent().toString())
        settings.addView(spacer(12))
        settings.addView(actionButton("Save settings", C_GREEN_DARK, C_GREEN) { saveSettings() })
        body.addView(settings)

        val reset = card()
        reset.addView(text("Reset paper account", 15f, C_TEXT, true))
        reset.addView(spacer(5))
        reset.addView(text("This permanently deletes the local journal and restores the paper balance to your configured initial balance.", 11f, C_MUTED))
        reset.addView(spacer(10))
        reset.addView(actionButton("Reset wallet and journal", C_RED_DARK, C_RED) {
            AlertDialog.Builder(this)
                .setTitle("Reset PaperFlip?")
                .setMessage("All paper trades and execution history on this phone will be deleted. This cannot be undone.")
                .setNegativeButton("Cancel", null)
                .setPositiveButton("Reset") { _, _ ->
                    store.deleteAllPaperData()
                    prefs.edit().putFloat(prefsBalanceKey, initialBalanceSol().toFloat()).apply()
                    loadedCoin = null
                    caDraft = ""
                    statusMessage = "Paper account reset. Paste a token CA to begin."
                    currentPage = Page.TRADE
                    toast("Paper account reset.")
                    renderPage()
                }
                .show()
        })
        body.addView(reset)

        val note = card(C_PANEL)
        note.addView(text("Data and privacy", 14f, C_TEXT, true))
        note.addView(spacer(5))
        note.addView(text("Trades, settings and the paper balance are stored in a private SQLite database on this phone. Market data requests go to the public DexScreener API. v0.1 does not request wallet, seed phrase or signing permissions.", 11f, C_MUTED))
        body.addView(note)
    }

    private fun addSettingField(parent: LinearLayout, title: String, key: String, value: String) {
        parent.addView(label(title))
        val field = editField(title, value)
        field.inputType = android.text.InputType.TYPE_CLASS_NUMBER or android.text.InputType.TYPE_NUMBER_FLAG_DECIMAL
        settingsFields[key] = field
        parent.addView(field)
        parent.addView(spacer(9))
    }

    private fun saveSettings() {
        val initial = settingsFields["initial"]?.text?.toString()?.toDoubleOrNull()
        val fee = settingsFields["feePct"]?.text?.toString()?.toDoubleOrNull()
        val fixed = settingsFields["fixedFee"]?.text?.toString()?.toDoubleOrNull()
        val slip = settingsFields["slippage"]?.text?.toString()?.toDoubleOrNull()
        if (initial == null || initial <= 0 || fee == null || fee < 0 || fixed == null || fixed < 0 || slip == null || slip < 0 || slip > 50) {
            toast("Check your values. Balance must be positive; fees cannot be negative; slippage must be 0–50%.")
            return
        }
        prefs.edit()
            .putFloat(prefsInitialBalanceKey, initial.toFloat())
            .putFloat("fee_percent", fee.toFloat())
            .putFloat("fixed_fee_sol", fixed.toFloat())
            .putFloat("slippage_percent", slip.toFloat())
            .apply()
        toast("Settings saved. The current wallet balance is unchanged.")
        renderPage()
    }

    private fun loadCoin(address: String) {
        if (!address.matches(Regex("[1-9A-HJ-NP-Za-km-z]{32,44}"))) {
            toast("That doesn't look like a Solana mint address.")
            return
        }
        loadingCoin = true
        statusMessage = "Looking up Solana pools on DexScreener…"
        renderPage()
        val preferredPool = store.getOpenPositions().firstOrNull { it.tokenAddress.equals(address, true) }?.pairAddress
        api.fetchSolanaToken(address, preferredPool) { result ->
            runOnUiThread {
                loadingCoin = false
                result.onSuccess { coin ->
                    loadedCoin = coin
                    caDraft = coin.address
                    statusMessage = "Token identified. Highest-liquidity eligible pool selected."
                    store.updateMarket(coin)
                    renderPage()
                }.onFailure { error ->
                    statusMessage = error.message ?: "Unable to load this token."
                    renderPage()
                    toast(statusMessage)
                }
            }
        }
    }

    private fun pasteAddress(target: EditText) {
        val clipboard = getSystemService(CLIPBOARD_SERVICE) as ClipboardManager
        val value = clipboard.primaryClip?.getItemAt(0)?.coerceToText(this)?.toString()?.trim().orEmpty()
        if (value.isBlank()) {
            toast("Your clipboard is empty.")
            return
        }
        target.setText(value)
        target.setSelection(target.text.length)
        caDraft = value
    }

    private fun executeBuy(coin: TokenMarket, notionalSol: Double) {
        if (!notionalSol.isFinite() || notionalSol <= 0.0) {
            toast("Enter a valid SOL amount.")
            return
        }
        val fee = notionalSol * feePercent() / 100.0 + fixedFeeSol()
        val totalDebit = notionalSol + fee
        if (totalDebit > balanceSol()) {
            toast("Insufficient paper SOL. Required ${fmtSol(totalDebit)} SOL including fees.")
            return
        }
        val executedPrice = coin.priceSol * (1.0 + slippagePercent() / 100.0)
        if (executedPrice <= 0.0 || !executedPrice.isFinite()) {
            toast("The token price is unavailable. Refresh before buying.")
            return
        }
        val tokenQty = notionalSol / executedPrice
        try {
            store.recordBuy(coin, notionalSol, fee, executedPrice, tokenQty)
            setBalance(balanceSol() - totalDebit)
            toast("Paper buy recorded: ${fmtSol(notionalSol)} SOL of ${coin.symbol}.")
            renderPage()
        } catch (error: Exception) {
            toast("Could not save paper buy: ${error.message}")
        }
    }

    private fun executeSell(position: TradePosition, percent: Double, coin: TokenMarket?) {
        val market = coin ?: loadedCoin
        val currentPrice = if (market != null && market.pairAddress == position.pairAddress) market.priceSol else position.latestPriceSol
        val currentMc = if (market != null && market.pairAddress == position.pairAddress) market.marketCap else position.latestMarketCap
        val executedPrice = currentPrice * (1.0 - slippagePercent() / 100.0)
        if (executedPrice <= 0.0 || !executedPrice.isFinite()) {
            toast("No usable market price is available for this position.")
            return
        }
        try {
            val result = store.recordSell(
                tradeId = position.id,
                percentOfRemaining = percent,
                executedPriceSol = executedPrice,
                marketCap = currentMc,
                feePercent = feePercent(),
                fixedFeeSol = fixedFeeSol()
            )
            setBalance(balanceSol() + result.netSol)
            toast("Paper sell recorded. ${if (result.isClosed) "Position closed." else "Position remaining: ${fmtQty(result.remainingTokenQty)} tokens."}")
            renderPage()
        } catch (error: Exception) {
            toast(error.message ?: "Could not record paper sell.")
        }
    }

    private fun refreshTrackedMarkets(showToast: Boolean) {
        val postExitCutoff = System.currentTimeMillis() - 24L * 60L * 60L * 1000L
        val tracked = store.getAllPositions().filter {
            it.isOpen || (it.closedAt != null && it.closedAt >= postExitCutoff)
        }.take(20)
        val pools = linkedMapOf<String, Pair<String, String>>()
        tracked.forEach { position ->
            pools["${position.tokenAddress}|${position.pairAddress}"] = position.tokenAddress to position.pairAddress
        }
        loadedCoin?.let { coin -> pools["${coin.address}|${coin.pairAddress}"] = coin.address to coin.pairAddress }
        if (pools.isEmpty()) {
            if (showToast) toast("No selected coin or recent positions to refresh.")
            return
        }
        var completed = 0
        val total = pools.size
        pools.values.forEach { (address, pairAddress) ->
            api.fetchSolanaToken(address, pairAddress) { result ->
                runOnUiThread {
                    result.onSuccess { coin ->
                        store.updateMarket(coin)
                        if (loadedCoin?.address.equals(address, true) && loadedCoin?.pairAddress.equals(pairAddress, true)) loadedCoin = coin
                    }
                    completed++
                    if (completed == total) {
                        if (currentPage == Page.JOURNAL || currentPage == Page.TRADE) renderPage()
                        if (showToast) toast("Market data refresh finished.")
                    }
                }
            }
        }
    }

    private fun balanceSol(): Double = prefs.getFloat(prefsBalanceKey, 7.44f).toDouble()
    private fun setBalance(value: Double) { prefs.edit().putFloat(prefsBalanceKey, value.toFloat()).apply() }
    private fun initialBalanceSol(): Double = prefs.getFloat(prefsInitialBalanceKey, 7.44f).toDouble()
    private fun feePercent(): Double = prefs.getFloat("fee_percent", 1.0f).toDouble()
    private fun fixedFeeSol(): Double = prefs.getFloat("fixed_fee_sol", 0.005f).toDouble()
    private fun slippagePercent(): Double = prefs.getFloat("slippage_percent", 0.5f).toDouble()

    private fun sectionTitle(title: String, subtitle: String) {
        val block = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(2), dp(6), dp(2), dp(9)) }
        block.addView(text(title, 12f, C_GREEN, true))
        block.addView(text(subtitle, 10f, C_MUTED))
        body.addView(block)
    }

    private fun sectionHeader(title: String, right: String): View {
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        row.addView(text(title, 12f, C_TEXT, true), LinearLayout.LayoutParams(0, -2, 1f))
        row.addView(text(right, 10f, C_GREEN, true))
        return row
    }

    private fun card(color: Int = C_CARD): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        background = rounded(color, dp(16), C_BORDER, dp(1))
        setPadding(dp(14), dp(14), dp(14), dp(14))
        layoutParams = LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(10) }
    }

    private fun metric(title: String, value: String, valueColor: Int): LinearLayout {
        val block = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        block.addView(label(title))
        block.addView(text(value, 14f, valueColor, true))
        return block
    }

    private fun label(value: String): TextView = text(value, 9f, C_MUTED, true).apply {
        letterSpacing = 0.06f
        setPadding(0, 0, 0, dp(5))
    }

    private fun text(value: String, size: Float, color: Int, bold: Boolean = false): TextView = TextView(this).apply {
        text = value
        textSize = size
        setTextColor(color)
        if (bold) typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
        includeFontPadding = true
    }

    private fun pill(value: String, bg: Int, fg: Int, size: Float): TextView = TextView(this).apply {
        text = value
        textSize = size
        typeface = Typeface.DEFAULT_BOLD
        setTextColor(fg)
        gravity = Gravity.CENTER
        setPadding(dp(9), dp(6), dp(9), dp(6))
        background = rounded(bg, dp(30))
    }

    private fun actionButton(value: String, bg: Int, fg: Int, onClick: () -> Unit): View = TextView(this).apply {
        text = value
        textSize = 12f
        typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
        setTextColor(fg)
        gravity = Gravity.CENTER
        setPadding(dp(7), dp(8), dp(7), dp(8))
        background = rounded(bg, dp(11), if (bg == C_GREEN_DARK) C_GREEN_BORDER else if (bg == C_RED_DARK) C_RED_BORDER else C_BORDER, dp(1))
        isClickable = true
        isFocusable = true
        setOnClickListener { onClick() }
    }

    private fun editField(hintText: String, value: String): EditText = EditText(this).apply {
        hint = hintText
        setText(value)
        textSize = 13f
        setTextColor(C_TEXT)
        setHintTextColor(C_MUTED)
        setSingleLine(true)
        background = rounded(C_INPUT, dp(11), C_BORDER, dp(1))
        setPadding(dp(12), dp(7), dp(12), dp(7))
    }

    private fun rounded(color: Int, radius: Int, stroke: Int? = null, strokeWidth: Int = 0): GradientDrawable =
        GradientDrawable().apply {
            setColor(color)
            cornerRadius = radius.toFloat()
            if (stroke != null && strokeWidth > 0) setStroke(strokeWidth, stroke)
        }

    private fun spacer(height: Int): View = View(this).apply { layoutParams = LinearLayout.LayoutParams(1, dp(height)) }
    private fun spacerWidth(width: Int): View = View(this).apply { layoutParams = LinearLayout.LayoutParams(dp(width), 1) }
    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

    private fun tokenAvatar(symbol: String, imageUrl: String, size: Int): View {
        val fallback = TextView(this).apply {
            text = symbol.take(2).uppercase(Locale.US)
            textSize = 12f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(C_BG)
            gravity = Gravity.CENTER
            background = rounded(C_GREEN, dp(size / 2))
        }
        if (imageUrl.isBlank() || !imageUrl.startsWith("https://")) return fallback

        val frame = FrameLayout(this).apply {
            background = rounded(C_GREEN_DARK, dp(size / 2))
            clipToOutline = true
        }
        frame.addView(fallback, FrameLayout.LayoutParams(-1, -1))
        val image = ImageView(this).apply {
            scaleType = ImageView.ScaleType.CENTER_CROP
            visibility = View.GONE
            clipToOutline = true
            contentDescription = "$symbol token image"
        }
        frame.addView(image, FrameLayout.LayoutParams(-1, -1))
        imageExecutor.execute {
            try {
                val connection = URL(imageUrl).openConnection().apply {
                    connectTimeout = 5_000
                    readTimeout = 5_000
                }
                val bitmap = connection.getInputStream().use { BitmapFactory.decodeStream(it) }
                if (bitmap != null) runOnUiThread {
                    image.setImageBitmap(bitmap)
                    image.visibility = View.VISIBLE
                }
            } catch (_: Exception) { /* Keep the symbol fallback visible. */ }
        }
        return frame
    }

    private fun pasteText() = (getSystemService(CLIPBOARD_SERVICE) as ClipboardManager)
    private fun copyText(value: String, message: String) {
        pasteText().setPrimaryClip(ClipData.newPlainText("PaperFlip", value))
        toast(message)
    }

    private fun openUrl(url: String) {
        try { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url))) }
        catch (_: Exception) { toast("No browser is available to open this link.") }
    }

    private fun toast(message: String) = Toast.makeText(this, message, Toast.LENGTH_SHORT).show()

    private fun fmtSol(value: Double): String = String.format(Locale.US, "%.4f", value)
    private fun signedSol(value: Double): String = (if (value >= 0) "+" else "") + fmtSol(value) + " SOL"
    private fun fmtQty(value: Double): String = when {
        value >= 1_000_000 -> String.format(Locale.US, "%.2fM", value / 1_000_000.0)
        value >= 1_000 -> String.format(Locale.US, "%.2fK", value / 1_000.0)
        value >= 1 -> String.format(Locale.US, "%.4f", value)
        else -> String.format(Locale.US, "%.5g", value)
    }
    private fun fmtPriceSol(value: Double): String = String.format(Locale.US, "%.5g SOL", value)
    private fun fmtUsd(value: Double): String = when {
        value <= 0.0 -> "—"
        value >= 1_000_000_000 -> String.format(Locale.US, "$%.2fB", value / 1_000_000_000.0)
        value >= 1_000_000 -> String.format(Locale.US, "$%.2fM", value / 1_000_000.0)
        value >= 1_000 -> String.format(Locale.US, "$%.1fK", value / 1_000.0)
        else -> String.format(Locale.US, "$%.0f", value)
    }
    private fun fmtOptionalMc(value: Double): String = if (value > 0) fmtUsd(value) else "Unavailable"
    private fun fmtMultiple(value: Double): String = String.format(Locale.US, "%.2f", value)
    private fun fmtOptionalMultiple(value: Double): String = if (value > 0.0 && value.isFinite()) "${fmtMultiple(value)}x" else "—"
    private fun shortAddress(value: String): String = if (value.length > 12) value.take(5) + "…" + value.takeLast(5) else value
    private fun timeClock(value: Long): String = SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(Date(value))
    private fun dateTime(value: Long): String = SimpleDateFormat("MMM d, HH:mm:ss", Locale.getDefault()).format(Date(value))
    private fun duration(start: Long, end: Long): String {
        val seconds = ((end - start).coerceAtLeast(0L) / 1000L)
        val days = seconds / 86_400
        val hours = (seconds % 86_400) / 3_600
        val minutes = (seconds % 3_600) / 60
        val secs = seconds % 60
        return when {
            days > 0 -> "${days}d ${hours}h ${minutes}m"
            hours > 0 -> "${hours}h ${minutes}m ${secs}s"
            else -> "${minutes}m ${secs}s"
        }
    }

    private class SimpleTextWatcher(private val onChanged: (String) -> Unit) : android.text.TextWatcher {
        override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) = Unit
        override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) { onChanged(s?.toString().orEmpty()) }
        override fun afterTextChanged(s: android.text.Editable?) = Unit
    }

    companion object {
        private const val C_BG = 0xFF080D14.toInt()
        private const val C_PANEL = 0xFF101A27.toInt()
        private const val C_CARD = 0xFF0E1722.toInt()
        private const val C_PANEL_LIGHT = 0xFF1A293A.toInt()
        private const val C_INPUT = 0xFF0B131D.toInt()
        private const val C_ACTIVE_TAB = 0xFF243447.toInt()
        private const val C_BORDER = 0xFF243346.toInt()
        private const val C_GREEN = 0xFF32D9A5.toInt()
        private const val C_GREEN_DARK = 0xFF103A31.toInt()
        private const val C_GREEN_BORDER = 0xFF16785F.toInt()
        private const val C_RED = 0xFFFF829A.toInt()
        private const val C_RED_DARK = 0xFF3B1C2B.toInt()
        private const val C_RED_BORDER = 0xFF9B3D5A.toInt()
        private const val C_TEXT = 0xFFF2F6FB.toInt()
        private const val C_MUTED = 0xFF98A8BB.toInt()
    }
}
