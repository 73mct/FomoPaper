# PaperFlip Android — v0.1

A native Android **paper-trading** prototype for Solana meme coins. It retrieves public market data from DexScreener and simulates buys/sells locally. It does not connect to a wallet, request a seed phrase, sign transactions, or spend real SOL.

## Included in this first build

- Paste a Solana mint/contract address and look up its pools on DexScreener.
- Prefer the highest-liquidity eligible pool; preserve the same pool for an existing trade when refreshing it.
- Show token name, ticker, available image, price in SOL, market cap (or FDV fallback), liquidity and 24-hour volume.
- Start with a paper balance of 7.44 SOL (editable in Settings).
- Quick buys of 0.25 / 0.5 / 1 / 2.5 SOL plus a custom amount.
- Partial sells of 25 / 50 / 75 / 100 percent of the **remaining** token quantity.
- Editable percentage fee, fixed fee and slippage assumptions.
- SQLite journal with token CA, pool, entry, each execution, fees, realized PnL, unrealized PnL, holding time and observed peak market-cap/FDV metric.
- Refresh market data while the app is open. For up to 24 hours after a trade closes, the app can continue recording an observed peak if that token remains among the tracked positions and the app is kept open.
- A GitHub Actions workflow to build a debug APK in the cloud after the project is pushed to a GitHub repository.

## Not included yet

The system-wide floating bubble/HUD is deliberately **not in v0.1**. This version validates the token lookup, fill simulation, balance accounting and journal first. The next development milestone is the Android overlay service (`TYPE_APPLICATION_OVERLAY`) with an expandable terminal and collapsed PnL bubble. The overlay needs the user's explicit Android "Display over other apps" permission and must be tested against FOMO, Axiom and HyperOS behavior.

CSV/JSON export, multi-chain support, chart drawing, automatic reading of another app's screen and real wallet trading are also not part of v0.1.

## Open in Android Studio (Windows)

1. Install Android Studio and let its setup wizard install the Android SDK.
2. Open this folder (`PaperFlipAndroid`) using **File → Open**.
3. When Android Studio asks to install missing components, install Android SDK Platform 36 and Build Tools 36.0.0.
4. Use JDK 17 for Gradle (Android Studio's bundled JBR is suitable if it is version 17).
5. Wait for Gradle sync. The included `gradlew.bat` bootstraps Gradle 8.13 on first use if needed.
6. Connect the Poco X6 Pro with USB debugging enabled, or use Android Studio's device selector.
7. Press **Run** to install the debug build.

You can also build from a Windows terminal in this directory:

```bat
.\gradlew.bat :app:assembleDebug
```

The debug APK will be written to:

```text
app\build\outputs\apk\debug\app-debug.apk
```

## Cloud build (useful when the laptop is slow)

The repository includes `.github/workflows/android-build.yml`.

1. Create a GitHub repository and upload/push the contents of this project.
2. Open the repository's **Actions** tab.
3. Run **Build PaperFlip Android APK**, or push a commit to `main`/`master`.
4. When the workflow succeeds, open the workflow run and download the `PaperFlip-debug-apk` artifact.
5. Transfer `app-debug.apk` to your Android phone and install it. Android may ask you to allow installation from that source.

A public GitHub repository can use GitHub-hosted Actions within GitHub's applicable free usage limits. Private repositories are subject to account quotas and limits.

## Using PaperFlip v0.1

1. Open the **Trade** tab.
2. Copy a Solana token mint/CA from FOMO or Axiom.
3. Paste it and tap **Load coin**.
4. Confirm the token, market cap, selected pool and liquidity.
5. Pick a SOL buy amount. The paper balance is debited by the notional plus the configured buy fee.
6. Use the sell buttons. Each sell percentage applies to the remaining token quantity. The balance receives simulated proceeds after the configured sell fee.
7. Check **Journal** for entries, fills, fees, realized/unrealized PnL, holding duration and the observed peak.
8. Adjust the fee/slippage assumptions in **Settings**.

## Simulation model

- Buy execution price = last observed SOL token price × (1 + slippage %).
- Sell execution price = last observed SOL token price × (1 − slippage %).
- Buy token quantity = buy notional SOL ÷ simulated execution price.
- Fee per fill = notional × fee percentage + fixed SOL fee.
- Sell quantity = chosen fraction × currently remaining token quantity.
- Cost basis is allocated proportionally to the quantity sold. Realized PnL = net sell proceeds − allocated buy cost basis.
- Unrealized PnL = current value of remaining tokens − remaining cost basis.

These are transparent approximations, not a replay of an exchange's order book or a guarantee of real execution prices. Real-world transaction priority fees, MEV, failed transactions, price impact, pool migrations and transaction-specific routing may differ.

## Data source and pool selection

The app uses DexScreener's public Solana token-pairs endpoint:

`https://api.dexscreener.com/token-pairs/v1/solana/{tokenAddress}`

It selects the highest-liquidity returned pool where the queried mint is the base token, unless refreshing an existing position, in which case it tries to retain that exact pair. It uses the API's `priceNative` for SOL-denominated simulation. If the response does not include a usable native-token price, it refuses to create fills rather than inventing one.

Some tokens/pools may not be supported by this v0.1 pool-direction rule. Missing market cap is shown as unavailable; FDV is clearly marked as an FDV fallback when used.

## Privacy and permissions

- Required permission: Internet access.
- No wallet or storage permission is requested.
- Paper trades and preferences are stored in the app's private SQLite database and SharedPreferences on this phone.
- Market-data lookups send the pasted public token mint to DexScreener.
- Uninstalling the app or clearing its storage removes local journal data. Export/backup is planned for a later version.

## Build configuration

- Kotlin 2.3.21
- Android Gradle Plugin 8.13.2
- Gradle 8.13
- Compile SDK 36 / target SDK 35 / minimum SDK 26
- JDK 17

## Current validation status

This source project has been prepared in the workspace, but it has **not been compiled or installed on a device in this environment** because an Android SDK and Android build tools are not installed here. The GitHub Actions workflow is included so the first APK can be built on a hosted runner; the resulting APK should then be smoke-tested on the Poco X6 Pro before relying on the simulated figures.
