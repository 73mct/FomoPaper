@echo off
setlocal
set GRADLE_VERSION=8.13
set CACHE_ROOT=%USERPROFILE%\.gradle\paperflip-wrapper
set GRADLE_HOME=%CACHE_ROOT%\gradle-%GRADLE_VERSION%

if not exist "%GRADLE_HOME%\bin\gradle.bat" (
  echo Downloading Gradle %GRADLE_VERSION% (one-time setup)...
  if not exist "%CACHE_ROOT%" mkdir "%CACHE_ROOT%"
  powershell -NoProfile -ExecutionPolicy Bypass -Command "$ErrorActionPreference='Stop'; $cache=Join-Path $env:USERPROFILE '.gradle\paperflip-wrapper'; $zip=Join-Path $cache 'gradle-8.13-bin.zip'; Invoke-WebRequest -UseBasicParsing 'https://services.gradle.org/distributions/gradle-8.13-bin.zip' -OutFile $zip; Expand-Archive -LiteralPath $zip -DestinationPath $cache -Force; Remove-Item $zip -Force"
  if errorlevel 1 exit /b 1
)
call "%GRADLE_HOME%\bin\gradle.bat" %*
exit /b %ERRORLEVEL%
